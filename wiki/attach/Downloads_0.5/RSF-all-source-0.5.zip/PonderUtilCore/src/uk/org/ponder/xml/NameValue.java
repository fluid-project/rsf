/*
 * Created on Sep 23, 2005
 */
package uk.org.ponder.xml;

public class NameValue {
  public String name;
  public String value;
  public NameValue() {}
  public NameValue(String name, String value) {
    this.name = name;
    this.value = value;
  }
}
