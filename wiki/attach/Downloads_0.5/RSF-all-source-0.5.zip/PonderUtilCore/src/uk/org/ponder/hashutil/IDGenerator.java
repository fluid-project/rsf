/*
 * Created on Dec 13, 2004
 */
package uk.org.ponder.hashutil;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public interface IDGenerator {
  public String generateID();
}
