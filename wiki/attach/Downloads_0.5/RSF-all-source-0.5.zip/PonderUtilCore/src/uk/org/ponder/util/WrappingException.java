package uk.org.ponder.util;

public interface WrappingException {
  public Throwable getTargetException();
  }
