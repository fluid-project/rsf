/*
 * Created on 15-Apr-2004
 */
package uk.org.ponder.swingutil;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;

/**
 * @author Bosmon
 *
 * The class 
 */
public class TreeModelAdapter implements TreeModelListener {

  public void treeNodesChanged(TreeModelEvent e) {
  }

  public void treeNodesInserted(TreeModelEvent e) {
  }

  public void treeNodesRemoved(TreeModelEvent e) {
  }

  public void treeStructureChanged(TreeModelEvent e) {
  }

}
