/*
 * Created on Sep 19, 2005
 */
package uk.org.ponder.util;

public interface Copiable {
  public Object copy();
}
