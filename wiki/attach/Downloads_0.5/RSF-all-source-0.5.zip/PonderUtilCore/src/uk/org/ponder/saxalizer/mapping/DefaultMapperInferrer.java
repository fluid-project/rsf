/*
 * Created on Sep 22, 2004
 */
package uk.org.ponder.saxalizer.mapping;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.HashSet;

import uk.org.ponder.saxalizer.DefaultInferrible;
import uk.org.ponder.saxalizer.SAMSList;
import uk.org.ponder.saxalizer.SAXAccessMethodSpec;
import uk.org.ponder.stringutil.StringList;
import uk.org.ponder.stringutil.StringSet;
import uk.org.ponder.util.EnumerationConverter;
import uk.org.ponder.util.Logger;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 *  
 */
public class DefaultMapperInferrer implements SAXalizerMapperInferrer {
  public void setChainedInferrer(SAXalizerMapperInferrer target) {
    throw new UnsupportedOperationException("Cannot chain from default inferrer");
    // We expect to be the head of the chain
  }
  
  private HashMap collectionmap = new HashMap();
  private HashSet defaultiblemap = new HashSet();
  
  public DefaultMapperInferrer() {
    addCollectionType(StringList.class, String.class);
    addCollectionType(StringSet.class, String.class);
  }

  public Class getContaineeType(Class collectiontype) {
    return (Class)collectionmap.get(collectiontype);
  }
  
  
  public void addCollectionType(Class collectiontype, Class containeetype) {
    collectionmap.put(collectiontype, containeetype);
  }
  

  public void setDefaultInferrible(Class clazz) {
    defaultiblemap.add(clazz);
  }

  public boolean isDefaultInferrible(Class clazz) {
    return DefaultInferrible.class.isAssignableFrom(clazz)
    || defaultiblemap.contains(clazz);
  }
  
  public static int accessorType(Method method) {
    String methodname = method.getName();
    if (methodname.length() <= 3) return -1;
    if (methodname.startsWith("get")) {
      if (method.getParameterTypes().length == 0) {
        return SAXAccessMethodSpec.GET_METHOD;
      }
    }
    if (methodname.startsWith("set") || methodname.startsWith("add")) {
      if (method.getParameterTypes().length == 1 && method.getReturnType().equals(Void.TYPE))
      return SAXAccessMethodSpec.SET_METHOD;
    }
    return -1;
  }
// TODO: check that this actually agrees with beans spec!
// implement "isXxxx" methods for pedants.
  public static String deBean(String methodname) {
    boolean isupperstart = Character.isUpperCase(methodname.charAt(4));
    return (isupperstart? methodname.charAt(3) : Character.toLowerCase(methodname.charAt(3)))
        + methodname.substring(4);
  }

  public static final String dePluralize(String accessname, Class returntype) {
    String togo = accessname;
    if (EnumerationConverter.isEnumerable(returntype)) {
      if (accessname.endsWith("s")) {
        togo = accessname.substring(0, accessname.length() - 1);
      }
    }  
    return togo;
  }
  
  /** Returns an new SAMS object with the given name.
   * @param tagname
   * @param clazz The *return* type of the method, hence empty for a set method.
   * @return
   */
  private SAXAccessMethodSpec byXMLNameSafe(SAMSList samslist, String tagname, Class clazz) {
    // must not fuse get and set at this point! Otherwise there will be
    // duplicate.
    SAXAccessMethodSpec spec = new SAXAccessMethodSpec();
    // depluralise if it is a get method 
    spec.xmlname = dePluralize(tagname, clazz);
  
    Class containeetype = getContaineeType(clazz);
    if (containeetype != null) {
      spec.clazz = containeetype;
    }
    return spec;
  }
  
  private static boolean isPublicNonStatic(int modifiers) {
    return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers);
  }
  
  public SAXalizerMapperEntry inferEntry(Class clazz, 
      SAXalizerMapperEntry preventry) {
    SAXalizerMapperEntry togo = preventry == null? new SAXalizerMapperEntry() : preventry;
    togo.targetclass = clazz;
    SAMSList sams = togo.getSAMSList();
    Method[] methods = clazz.getMethods();
    if (Logger.log.isDebugEnabled()) {
      Logger.log.debug("Inferring default mapping for " + clazz);
    }
    for (int i = 0; i < methods.length; ++i) {
      int modifiers = methods[i].getModifiers(); 
      if (!isPublicNonStatic(modifiers)) continue;
      String methodname = methods[i].getName();
      if (methodname.equals("getClass")) continue;
      int methodtype = accessorType(methods[i]);
      if (Logger.log.isDebugEnabled()) {
        Logger.log.debug("Method " + methodname + " access type " + methodtype);
      }
      if (methodtype != -1) {
        String basename = deBean(methodname);
        SAXAccessMethodSpec spec = byXMLNameSafe(sams, basename, methods[i].getReturnType());
        if (methodtype == SAXAccessMethodSpec.GET_METHOD) {
          spec.getmethodname = methodname;
        }
        else {
          spec.setmethodname = methodname;
        }
        if (Logger.log.isDebugEnabled()) {
          Logger.log.debug("Method gave access method " + spec);
        }
        spec.xmlname += "*"; // better make everything polymorphic
        togo.addNonDuplicate(spec);
      }
    }

    Field[] fields = clazz.getFields();
    for (int i = 0; i < fields.length; ++i) {
      String fieldname = fields[i].getName();
      int modifiers = fields[i].getModifiers();
      if (!isPublicNonStatic(modifiers)) continue;
      SAXAccessMethodSpec spec = byXMLNameSafe(sams, fieldname, fields[i].getType());
      spec.accesstype = SAXAccessMethodSpec.ACCESS_FIELD;
      spec.fieldname = fieldname;
      if (Logger.log.isDebugEnabled()) {
        Logger.log.debug("Field gave access method " + spec);
      }
      spec.xmlname += "*"; // better make everything polymorphic
      togo.addNonDuplicate(spec);
    }
    
    return togo;
  }


}