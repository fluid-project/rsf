//   --   @(#)SizeOverflowException.java 1.4 99/03/22

package uk.org.ponder.matrix;

public class SizeOverflowException extends RuntimeException {}
