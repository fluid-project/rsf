/*
 * Created on Jun 21, 2005
 */
package uk.org.ponder.util;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public interface RunnableWrapper {
  public Runnable wrapRunnable(Runnable towrap);
}
