package uk.org.ponder.matrix;

public interface BinaryFunction{
    double apply(double arg1, double arg2);
    }
