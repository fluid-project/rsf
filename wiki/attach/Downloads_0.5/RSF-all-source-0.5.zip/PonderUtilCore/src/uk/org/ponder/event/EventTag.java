package uk.org.ponder.event;
/** EventTag is an empty interface indicating that the implementing class constitutes
 * an event.
 */
public interface EventTag{}
