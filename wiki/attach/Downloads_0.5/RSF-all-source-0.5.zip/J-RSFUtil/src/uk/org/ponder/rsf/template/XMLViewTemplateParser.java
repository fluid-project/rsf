/*
 * Created on Oct 21, 2005
 */
package uk.org.ponder.rsf.template;

public class XMLViewTemplateParser {

}
