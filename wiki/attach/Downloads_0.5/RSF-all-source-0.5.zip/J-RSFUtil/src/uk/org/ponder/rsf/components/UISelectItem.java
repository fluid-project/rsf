/*
 * Created on Aug 8, 2005
 */
package uk.org.ponder.rsf.components;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public class UISelectItem {
  public String value;
  public String text;
  public UISelectItem(String value, String text) {
    this.value = value;
    this.text = text;
  }
}
