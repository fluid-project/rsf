/*
 * Created on Aug 11, 2005
 */
package uk.org.ponder.rsf.view;

public interface ViewComponentProducer extends ComponentProducer {
  public String getViewID();
}
