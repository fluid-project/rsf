/*
 * Created on Nov 25, 2005
 */
package uk.org.ponder.rsf.flow;

public interface ARIResolver {
  public ActionResultInterpreter getActionResultInterpreter();
}
