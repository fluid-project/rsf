/*
 * Created on Nov 23, 2005
 */
package uk.org.ponder.rsf.flow.lite;

public class EndState extends ViewableState {
  
}
