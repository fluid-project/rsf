/*
 * Created on Nov 12, 2005
 */
package uk.org.ponder.rsf.state;

public class NullVersionCheckPolicy implements VersionCheckPolicy {

  public void checkOldVersion(SubmittedValueEntry sve) {
  }

}
