/*
 * Created on Nov 12, 2005
 */
package uk.org.ponder.rsf.state;

import uk.org.ponder.rsf.request.SubmittedValueEntry;

public class NullVersionCheckPolicy implements VersionCheckPolicy {

  public void checkOldVersion(SubmittedValueEntry sve) {
  }

}
