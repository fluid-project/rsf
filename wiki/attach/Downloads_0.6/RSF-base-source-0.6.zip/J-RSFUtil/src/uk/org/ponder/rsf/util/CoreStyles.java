/*
 * Created on Nov 24, 2004
 */
package uk.org.ponder.rsf.util;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public class CoreStyles {
  public static final String STYLE_ERROR="error-message-style-class";
}
