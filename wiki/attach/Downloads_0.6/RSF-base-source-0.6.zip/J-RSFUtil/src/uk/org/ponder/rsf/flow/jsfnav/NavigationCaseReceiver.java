/*
 * Created on 13-Feb-2006
 */
package uk.org.ponder.rsf.flow.jsfnav;

import java.util.List;

public interface NavigationCaseReceiver {
  public void receiveNavigationCases(String viewid, List navigationCases);
}
