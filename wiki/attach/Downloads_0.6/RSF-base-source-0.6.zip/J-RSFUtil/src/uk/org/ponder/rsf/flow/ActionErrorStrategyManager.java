/*
 * Created on Dec 3, 2005
 */
package uk.org.ponder.rsf.flow;

import java.util.ArrayList;
import java.util.List;

import uk.org.ponder.errorutil.CoreMessages;
import uk.org.ponder.errorutil.TargettedMessage;
import uk.org.ponder.errorutil.ThreadErrorState;
import uk.org.ponder.util.UniversalRuntimeException;

/** A collection point for ActionErrorStrategies. Tries each strategy in 
 * turn, and if none match the criteria for the current error, adopts 
 * a default strategy.
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 *
 */

public class ActionErrorStrategyManager implements ActionErrorStrategy {
  private List strategies = new ArrayList();

  public void setMergeStrategies(ActionErrorStrategyManager strategies) {
    this.strategies.addAll(strategies.getStrategies());
  }

  public void addStrategy(ActionErrorStrategy toadd) {
    strategies.add(toadd);
  }

  public ActionErrorStrategy strategyAt(int i) {
    return (ActionErrorStrategy) strategies.get(i);
  }

  public List getStrategies() {
    return strategies;
  }

  public boolean handleError(String returncode, Exception exception,
      String flowstate, String viewID) {
    boolean code = false;
    for (int i = 0; i < strategies.size(); ++i) {
      code = strategyAt(i)
          .handleError(returncode, exception, flowstate, viewID);
      if (code)
        return true;
    }
    if (exception != null && !code) {
//      Logger.log.error("Error invoking action", exception);
      ThreadErrorState.addError(new TargettedMessage(
          CoreMessages.GENERAL_ACTION_ERROR));
      throw UniversalRuntimeException.accumulate(exception,
          "Error invoking action");
    }
    return false;
  }

}
