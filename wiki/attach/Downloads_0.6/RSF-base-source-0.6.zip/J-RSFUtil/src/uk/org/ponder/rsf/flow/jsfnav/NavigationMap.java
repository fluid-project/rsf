/*
 * Created on 10-Feb-2006
 */
package uk.org.ponder.rsf.flow.jsfnav;

import java.util.List;

public class NavigationMap {
  public List navigationRules;
}
