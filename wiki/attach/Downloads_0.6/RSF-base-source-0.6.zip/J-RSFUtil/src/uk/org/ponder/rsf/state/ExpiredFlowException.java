/*
 * Created on Dec 1, 2005
 */
package uk.org.ponder.rsf.state;

public class ExpiredFlowException extends RuntimeException {

}
