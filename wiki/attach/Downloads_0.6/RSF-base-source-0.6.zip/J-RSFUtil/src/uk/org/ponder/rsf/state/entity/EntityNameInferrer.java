/*
 * Created on 14-Feb-2006
 */
package uk.org.ponder.rsf.state.entity;

public interface EntityNameInferrer {
  public String getEntityName(Class entityclazz);
}
