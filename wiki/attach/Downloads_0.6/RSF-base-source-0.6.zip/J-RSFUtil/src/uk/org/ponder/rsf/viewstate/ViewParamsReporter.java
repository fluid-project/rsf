/*
 * Created on 13-Feb-2006
 */
package uk.org.ponder.rsf.viewstate;

public interface ViewParamsReporter {
  public ViewParameters getViewParameters();
}
