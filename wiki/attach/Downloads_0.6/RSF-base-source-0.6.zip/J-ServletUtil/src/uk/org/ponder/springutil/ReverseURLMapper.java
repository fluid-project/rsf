/*
 * Created on Jun 15, 2005
 */
package uk.org.ponder.springutil;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public interface ReverseURLMapper {
  public String URLforBean(String beanname);
}
