package uk.org.ponder.matrix;

public interface UnaryFunction {
    double apply(double arg);
    }
