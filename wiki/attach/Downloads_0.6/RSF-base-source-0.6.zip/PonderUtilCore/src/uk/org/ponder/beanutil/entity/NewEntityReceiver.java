/*
 * Created on 10-Jan-2006
 */
package uk.org.ponder.beanutil.entity;

public interface NewEntityReceiver {
  public void receiveNewEntity(NewEntityEntry entry);
}
