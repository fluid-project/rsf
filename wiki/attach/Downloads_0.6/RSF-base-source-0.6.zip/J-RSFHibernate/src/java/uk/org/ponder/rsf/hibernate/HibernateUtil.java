/*
 * Created on 02-Feb-2006
 */
package uk.org.ponder.rsf.hibernate;

import uk.org.ponder.util.Logger;
import net.sf.hibernate.Session;
import net.sf.hibernate.Transaction;

/**
 * Cleanup methods necessary for Hibernate 2.x which has not yet moved over to
 * unchecked exceptions.
 * 
 * @author Antranig Basman (amb26@ponder.org.uk)
 * 
 */
public class HibernateUtil {
  public static void closeSession(Session toclose) {
    if (toclose != null) {
      try {
        toclose.close();
      }
      catch (Exception e) {

        try {
          Logger.log.error("Error closing session", e);
        }
        catch (Throwable t) {
        }
      }
    }
  }

  public static void rollbackTransaction(Transaction trans) {
    if (trans != null) {
      try {
        trans.rollback();
      }
      catch (Exception e) {
        try {
          Logger.log.error("Error rolling back transaction", e);
        }
        catch (Throwable t) {
        }
      }
    }
  }

}
