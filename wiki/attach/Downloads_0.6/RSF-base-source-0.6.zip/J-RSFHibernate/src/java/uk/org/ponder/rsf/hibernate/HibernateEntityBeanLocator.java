/*
 * Created on 05-Jan-2006
 */
package uk.org.ponder.rsf.hibernate;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.metadata.ClassMetadata;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;

import uk.org.ponder.beanutil.BeanUtil;
import uk.org.ponder.beanutil.entity.NewEntityEntry;
import uk.org.ponder.beanutil.entity.NewEntityReceiver;
import uk.org.ponder.conversion.StaticLeafParser;
import uk.org.ponder.reflect.ReflectiveCache;
import uk.org.ponder.rsf.state.entity.ObstinateEntityBeanLocator;
import uk.org.ponder.saxalizer.SAXalizerMappingContext;
import uk.org.ponder.util.UniversalRuntimeException;

/**
 * A form of "DAO" managing a section of the request container namespace
 * corresponding to all entities of a Hibernate-mapped type. See documentation
 * on {@link uk.org.ponder.rsf.state.entity.ObstinateEntityBeanLocator} for
 * details on semantics.
 * 
 * <p>
 * Set either "entityClass" or "entityName" to determine the mapped entity and
 * hence Java class for this locator. Note that the Hibernate entity name
 * defaults to the unqualified class name
 * {@link http://docs.jboss.org/ejb3/app-server/HibernateEntityManager/reference/en/html_single/}
 * (this functionality not supported until re-upgrade to Hibernate 3.x)
 * 
 * <p>
 * These are request-scope beans, but not created by RSAC for reasons of
 * efficiency. These are auto-populated by the StaticHibernateEBM for each
 * request.
 * 
 * @author Antranig Basman (amb26@ponder.org.uk)
 * 
 */

public class HibernateEntityBeanLocator implements ObstinateEntityBeanLocator {
  private Map delivered = new HashMap();
  private Class clazz;
  private Class idclazz;

  private HibernateAlterationWrapper haw;
  private ReflectiveCache reflectivecache;
  private SessionFactory sessionfactory;
  private ClassMetadata classmetadata;
  private StaticLeafParser parser;
  private NewEntityReceiver entityreceiver;

  // One request-scope dependency. Basically we must have some, or could not
  // resolve the Session.
  public void setHibernateAlterationWrapper(HibernateAlterationWrapper haw) {
    this.haw = haw;
  }

  // Two application-scope dependencies
  public void setSessionFactory(SessionFactory sessionfactory) {
    this.sessionfactory = sessionfactory;
  }

  public void setMappingContext(SAXalizerMappingContext mappingcontext) {
    this.reflectivecache = mappingcontext.getReflectiveCache();
    this.parser = mappingcontext.saxleafparser;
  }

  private void setClassMetadata(ClassMetadata classmetadata) {
    this.classmetadata = classmetadata;
    this.idclazz = classmetadata.getIdentifierType().getReturnedClass();
  }

  public void setEntityClass(Class clazz) {
    this.clazz = clazz;
    try {
      setClassMetadata(sessionfactory.getClassMetadata(clazz));
    }
    catch (HibernateException he) {
      throw UniversalRuntimeException.accumulate(he,
          "Error locating class metadata for " + clazz);
    }
  }

  public void setNewEntityReceiver(NewEntityReceiver entityreceiver) {
    this.entityreceiver = entityreceiver;
  }

  public Class getIDClass() {
    return idclazz;
  }

  /*
   * Not supported under Hibernate 2.x public void setEntityName(String
   * entityname) { try {
   * setClassMetadata(sessionfactory.getClassMetadata(entityname)); } catch
   * (HibernateException he) { throw UniversalRuntimeException.accumulate(he,
   * "Error locating class metadata for entity" + entityname); } this.clazz =
   * classmetadata.getMappedClass(// EntityMode.POJO ); }
   */
  public Serializable getID(Object idfor) {
    try {
      return classmetadata.getIdentifier(idfor /* , EntityMode.POJO */);
    }
    catch (HibernateException he) {
      throw UniversalRuntimeException.accumulate(he,
          "Error getting ID of object " + idfor);
    }
  }

  public String getIDString(Object idfor) {
    Serializable sez = getID(idfor);
    // the point of this rendering is that it be the inverse of the parsing
    // performed in locateBean. I note that Hibernate is not terribly careful
    // about such things, but given that all IDs in practice are either Int,
    // Long, or String, it is not terribly important.
    return parser.render(sez);
  }

  private void registerNewEntity(String id, Object newent) {
    entityreceiver.receiveNewEntity(new NewEntityEntry(newent, id, this));
    delivered.put(id, newent);
  }

  public Object locateBean(String path) {
    Object togo = null;
    // Assume this is even FASTER than Hibernate 1st-level cache :P
    togo = delivered.get(path);
    if (togo == null) {
      if (path.startsWith(BeanUtil.NEW_ENTITY_PREFIX)) {
        togo = reflectivecache.construct(clazz);
        registerNewEntity(path, togo);
      }
      else {
        try {
          Serializable beanid = (Serializable) parser.parse(idclazz, path);
          togo = haw.getSession().get(clazz, beanid);
        }
        catch (Exception e) {
          throw UniversalRuntimeException.accumulate(e,
              "Error getting bean with ID " + path + " of " + clazz);
        }
        if (togo == null) {
          throw new NoSuchBeanDefinitionException(path, "No entity of " + clazz
              + " with ID " + path + " could be found");
        }
      }
      delivered.put(path, togo);

    }
    return togo;
  }

  public boolean remove(String beanname) {
    try {
      Object bean = locateBean(beanname);
      haw.getSession().delete(bean);
      delivered.remove(beanname);
    }
    catch (Exception e) {
      throw UniversalRuntimeException.accumulate(e,
          "Error removing bean with name " + beanname + " of " + clazz);
    }
    return true; // if the bean did not exist, there will be an exception in
    // any case
  }

  public void set(String beanname, Object toset) {
    if (beanname.startsWith(BeanUtil.NEW_ENTITY_PREFIX)) {
      registerNewEntity(beanname, toset);
    }
    else {
      try {
        haw.getSession().update(toset);
      }
      catch (Exception e) {
        throw UniversalRuntimeException.accumulate(e,
            "Error updating bean with id " + beanname + " of " + clazz);
      }
      delivered.put(beanname, toset);
    }

  }
  /** Returns an iterator of PREVIOUSLY DELIVERED beans */
  public Iterator iterator() {
    return delivered.keySet().iterator();
  }

  /** Package-protected access to "dead" list of delivered beans */
  Map getDeliveredBeans() {
    return delivered;
  }
}
