/*
 * Created on 08-Jan-2006
 */
package uk.org.ponder.rsf.hibernate;

import java.util.List;

import org.springframework.beans.factory.FactoryBean;

import net.sf.hibernate.Session;
/** A request-scope query bean that will return a list of objects in response
 * to an HQL query string.
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 *
 */
public class HQLQueryBean implements FactoryBean {
  private Session session;
  private String hqlstring;

  public void setSession(Session session) {
    this.session = session;
  }
  
  public void setHQLString(String hqlstring) {
    this.hqlstring = hqlstring;
  }

  private List cached;
  
  public Object getObject() throws Exception {
    if (cached == null) {
      cached = session.find(hqlstring); 
    }
    return cached;
  }

  public Class getObjectType() {
    return List.class;
  }

  public boolean isSingleton() {
   return true;
  }
}
