/*
 * Created on 09-Jan-2006
 */
package uk.org.ponder.rsf.hibernate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;
import net.sf.hibernate.mapping.PersistentClass;

import org.springframework.orm.hibernate.LocalSessionFactoryBean;

import uk.org.ponder.rsf.state.entity.EntityNameInferrer;
import uk.org.ponder.saxalizer.SAXalizerMappingContext;
import uk.org.ponder.stringutil.StringList;
import uk.org.ponder.util.Logger;

/**
 * The central point of Hibernate dependency. Inspects the Hibernate
 * Configuration, and manages the construction of individual
 * HibernateEntityBeanLocators to provide mapping for each Hibernate-managed
 * entity class. As much as possible application-scope state is centralised
 * in this class, with request-scope state in HibernateEntityBeanManager
 * and HibernateEntityBeanLocators.
 * 
 * @author Antranig Basman (amb26@ponder.org.uk)
 * 
 */

public class StaticHibernateEBM implements EntityNameInferrer {

  private List classes;
  private String entitynames;

  private Map nametoclass = new HashMap();

  public void setClasses(List classes) {
    this.classes = classes;
  }

  public void setEntityNames(String entitynames) {
    this.entitynames = entitynames;
  }

  private SessionFactory sessionfactory;
  private SAXalizerMappingContext mappingcontext;
  private Configuration config;

  // Two application-scope dependencies
  public void setLocalSessionFactoryBean(LocalSessionFactoryBean lsfb) {
    config = lsfb.getConfiguration();
    sessionfactory = (SessionFactory) lsfb.getObject();
  }

  public void setMappingContext(SAXalizerMappingContext mappingcontext) {
    this.mappingcontext = mappingcontext;
  }

  // The entity name is simply defined as the unqualified Java class name.
  // Hibernate's PersistentClass.getName() only returns the class name anyway.
  public String getEntityName(Class clazz) {
    String classname = clazz.getName();
    int lastdotpos = classname.lastIndexOf('.');
    String nick = classname.substring(lastdotpos + 1);
    return nick;
  }

  public void init() {
    boolean popclasses = false;
    if (classes == null || classes.size() == 0) {
      popclasses = true;
      classes = new ArrayList();
    }
    // Load ALL mapped classes into lookup table
    for (Iterator pcit = config.getClassMappings(); pcit.hasNext();) {
      PersistentClass pc = (PersistentClass) pcit.next();
      Class clazz = pc.getMappedClass();
      nametoclass.put(getEntityName(clazz), clazz);
      if (popclasses)
        classes.add(clazz);
    }
    // If entitynames supplied, look them up in the just built table.
    if (entitynames != null) {
      classes.clear();
      StringList names = StringList.fromString(entitynames);
      for (int i = 0; i < names.size(); ++i) {
        String entityname = names.stringAt(i);
        Class entityclazz = (Class) nametoclass.get(entityname);
        if (entityclazz == null) {
          Logger.log
              .error("Unable to find mapped class for name " + entityname);
        }
        else {
          classes.add(entityclazz);
        }
      }
    }

  }

  public void populateRequestMap(Map locators) {
    // Create a locator for each determined mapped class
    for (int i = 0; i < classes.size(); ++i) {
      Class entityclazz = (Class) classes.get(i);
      HibernateEntityBeanLocator hebl = new HibernateEntityBeanLocator();
      hebl.setSessionFactory(sessionfactory);
      hebl.setMappingContext(mappingcontext);
      hebl.setEntityClass(entityclazz);
     
      String entityname = getEntityName(entityclazz);

      locators.put(entityname, hebl);
    }
  }

//
//  public void postParse(EntityID toadjust) {
//    try {
//    ClassMetadata classmetadata = sessionfactory.getClassMetadata(toadjust.clazz);
//    Class IDclazz = classmetadata.getIdentifierType().getReturnedClass();
//  
//    toadjust.id = (Serializable) leafparser
//        .parse(IDclazz, (String) toadjust.id);
//    }
//    catch (Exception e) {
//      throw UniversalRuntimeException.accumulate("Error parsing ID for " + entityID);
//    }
//  }
//
//  public void preRender(EntityID toadjust) {
//    toadjust.id = leafparser.render(toadjust.id);
//
//  }


}
