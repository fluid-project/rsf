package uk.org.ponder.rsf.cookbook;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class Recipe implements Serializable {

    /** identifier field */
    private Integer id;

    /** persistent field */
    private String title;

    /** nullable persistent field */
    private String description;

    /** nullable persistent field */
    private Date date;

    /** nullable persistent field */
    private String instructions;

    /** full constructor */
    public Recipe(String title, String description, Date date, String instructions) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.instructions = instructions;
    }

    /** default constructor */
    public Recipe() {
    }

    /** minimal constructor */
    public Recipe(String title) {
        this.title = title;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getInstructions() {
        return this.instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
