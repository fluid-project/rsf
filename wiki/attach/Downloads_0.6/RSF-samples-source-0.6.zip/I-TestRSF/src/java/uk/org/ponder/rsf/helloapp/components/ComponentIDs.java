/*
 * Created on Nov 17, 2005
 */
package uk.org.ponder.rsf.helloapp.components;

public class ComponentIDs {
  public static final String MESSAGEFIELD = "messagefield";
}
