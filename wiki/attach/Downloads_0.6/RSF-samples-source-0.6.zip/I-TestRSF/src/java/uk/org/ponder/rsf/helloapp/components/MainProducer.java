/*
 * Created on Nov 17, 2005
 */
package uk.org.ponder.rsf.helloapp.components;

import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.DefaultView;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.ViewParameters;

public class MainProducer implements ViewComponentProducer, DefaultView {

  public String getViewID() {
    return "main";
  }

  public void fillComponents(UIContainer tofill, ViewParameters origviewparams, 
      ComponentChecker checker) {
    UIOutput.make(tofill, ComponentIDs.MESSAGEFIELD, null, "#{hellobean.message}");
  } 
 
}
