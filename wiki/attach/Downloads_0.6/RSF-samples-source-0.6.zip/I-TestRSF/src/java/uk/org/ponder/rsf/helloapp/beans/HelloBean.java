/*
 * Created on Nov 17, 2005
 */

package uk.org.ponder.rsf.helloapp.beans;

public class HelloBean {
  private String message = "Hello Reasonable World!";
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public String getMessage() {
    return message;
  }
}
