/*
 * Copyright 2002-2004 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.springframework.webflow.samples.numberguess;

import java.util.Calendar;

/**
 * Action that encapsulates logic for the number guess sample flow.
 * 
 * @author Keri Donald
 * @author Keith Donald
 * @author Antranig Basman
 */
public class FourDigitNumberGuessAction {
  // Important changes for RSF - mention of MultiAction and RequestScope are
  // removed, this class becomes a bean once more. Instead of being fetched
  // from the request, "data" and "guess" are set as bean properties.

  public FourDigitNumberGuessData data;
  public String guess;

  public String guess() {
    if (guess == null || guess.length() != 4) {
      return ActionResults.INVALID_INPUT;
    }
    for (int i = 0; i < 4; i++) {
      if (!Character.isDigit(guess.charAt(i))) {
        return ActionResults.INVALID_INPUT;
      }
      int digit = Character.getNumericValue(guess.charAt(i));
      for (int j = 0; j < i; j++) {
        if (digit == Character.getNumericValue(guess.charAt(j))) {
          return ActionResults.INVALID_INPUT;
        }
      }
    }
    int rightPosition = 0;
    int correctButWrongPosition = 0;
    for (int i = 0; i < guess.length(); i++) {
      char digit = guess.charAt(i);
      for (int j = 0; j < data.answer.length(); j++) {
        char answerDigit = data.answer.charAt(j);
        if (digit == answerDigit) {
          if (i == j) {
            rightPosition++;
          }
          else {
            correctButWrongPosition++;
          }
          break;
        }
      }
    }
    data.recordGuessData(guess, rightPosition, correctButWrongPosition);
    if (rightPosition == 4) {
      Calendar now = Calendar.getInstance();
      long durationMilliseconds = now.getTime().getTime()
          - data.start.getTime().getTime();
      data.durationSeconds = durationMilliseconds / 1000;
      return ActionResults.CORRECT;
    }
    else {
      return ActionResults.RETRY;
    }
  }

}