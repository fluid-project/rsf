/*
 * Created on Nov 22, 2005
 */
package org.springframework.webflow.samples.numberguess;

public class GuessData {
  private String guess;
  
  private int rightPosition;
  
  private int correctButWrongPosition;

  public GuessData(String guess, int rightPosition, int correctButWrongPosition) {
      this.guess = guess;
      this.rightPosition = rightPosition;
      this.correctButWrongPosition = correctButWrongPosition;
  }
  
  public int getCorrectButWrongPosition() {
      return correctButWrongPosition;
  }

  public String getGuess() {
      return guess;
  }

  public int getRightPosition() {
      return rightPosition;
  }   
}