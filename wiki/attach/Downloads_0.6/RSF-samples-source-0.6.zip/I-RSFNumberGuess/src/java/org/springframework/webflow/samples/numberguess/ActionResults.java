/*
 * Created on Nov 22, 2005
 */
package org.springframework.webflow.samples.numberguess;

public class ActionResults {
  public static final String INVALID_INPUT = "invalidInput";
  public static final String CORRECT = "correct";
  public static final String RETRY = "retry";
  public static final String SUCCESS = "success";
}
