/*
 * Created on Nov 22, 2005
 */
package org.springframework.webflow.samples.numberguess;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Random;

/**
 * Simple data holder for number guess info.
 */
public class NumberGuessData implements Serializable {
    
    private static Random random = new Random();

    Calendar start = Calendar.getInstance();

    // cheat for now and make the answer constant!
    int answer = 37;//random.nextInt(101);

    int guesses = 0;

    String lastGuessResult = "";

    long durationSeconds = -1;

    // property accessors for JSTL EL

    public int getAnswer() {
        return answer;
    }

    public long getDurationSeconds() {
        return durationSeconds;
    }

    public int getGuesses() {
        return guesses;
    }

    public String getLastGuessResult() {
        return lastGuessResult;
    }
}