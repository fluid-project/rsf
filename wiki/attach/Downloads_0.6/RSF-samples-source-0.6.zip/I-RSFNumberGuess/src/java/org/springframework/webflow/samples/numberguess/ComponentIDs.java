/*
 * Created on Nov 22, 2005
 */
package org.springframework.webflow.samples.numberguess;

public class ComponentIDs {

}
