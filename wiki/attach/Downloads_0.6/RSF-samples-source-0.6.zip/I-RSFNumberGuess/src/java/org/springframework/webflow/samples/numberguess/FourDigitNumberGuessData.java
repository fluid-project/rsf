/*
 * Created on Nov 22, 2005
 */
package org.springframework.webflow.samples.numberguess;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * Simple data holder for number guess info.
 */
public class FourDigitNumberGuessData implements Serializable {

  private static Random random = new Random();
  // Change for RSF: these three fields made package visible due to
  // class unbundle. This class becomes a bean again.
  Calendar start = Calendar.getInstance();
  String answer;
  long durationSeconds = -1;

  private List guessHistory = new ArrayList();

  // property accessors for JSTL EL

  public FourDigitNumberGuessData() {
    this.answer = createAnswer();
  }

  public void recordGuessData(String guess, int rightPosition,
      int correctButWrongPosition) {
    guessHistory.add(new GuessData(guess, rightPosition,
        correctButWrongPosition));
  }

  public String createAnswer() {
    return "0512"; // cheat for now and make the answer constant!
//    StringBuffer buffer = new StringBuffer(4);
//    for (int i = 0; i < 4; i++) {
//      int digit = random.nextInt(10);
//      for (int j = 0; j < i; j++) {
//        if (digit == Character.getNumericValue(buffer.charAt(j))) {
//          j = -1;
//          digit = random.nextInt(10);
//        }
//      }
//      buffer.append(digit);
//    }
//    return buffer.toString();
  }

  public String getAnswer() {
    return answer;
  }

  public long getDurationSeconds() {
    return durationSeconds;
  }

  public int getGuesses() {
    return guessHistory.size();
  }
// return type changed from Collection to List for RSF - cannot generate stable
// EL reference to bare Collection member.
  public List getGuessHistory() {
    return guessHistory;
  }

  public GuessData getLastGuessData() {
    if (guessHistory.isEmpty()) {
      return null;
    }
    return (GuessData) guessHistory.get(guessHistory.size() - 1);
  }
}
