/*
 * Copyright 2002-2004 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.springframework.webflow.samples.numberguess;

import java.util.Calendar;

/**
 * Action that encapsulates logic for the number guess sample flow.
 * 
 * @author Erwin Vervaet
 * @author Keith Donald
 * @author Antranig Basman
 */
public class NumberGuessAction {
  // Important changes for RSF - mention of MultiAction and RequestScope are
  // removed, this class becomes a bean once more. Instead of being fetched
  // from the request, "data" and "guess" are set as bean properties.
  public NumberGuessData data;
  public int guess;

  public String guess() {

    if (guess < 0 || guess > 100) {
      data.lastGuessResult = "invalid";
      return ActionResults.INVALID_INPUT;
    }
    else {
      data.guesses++;
      if (data.answer < guess) {
        data.lastGuessResult = "too high!";
        return ActionResults.RETRY;
      }
      else if (data.answer > guess) {
        data.lastGuessResult = "too low!";
        return ActionResults.RETRY;
      }
      else {
        data.lastGuessResult = "correct!";
        Calendar now = Calendar.getInstance();
        long durationMilliseconds = now.getTime().getTime()
            - data.start.getTime().getTime();
        data.durationSeconds = durationMilliseconds / 1000;
        return ActionResults.SUCCESS;
      }
    }
  }

}