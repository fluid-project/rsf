/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import java.text.SimpleDateFormat;
import java.util.List;

import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UIBranchContainer;
import uk.org.ponder.rsf.components.UICommand;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIDeletionBinding;
import uk.org.ponder.rsf.components.UIForm;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.cookbook.Category;
import uk.org.ponder.rsf.cookbook.Recipe;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;

public class Recipes implements ViewComponentProducer {
  public static final String VIEW_ID = "recipes";
  private List recipelist;
  public String getViewID() {
    return VIEW_ID;
  }

  public void setRecipeList(List recipelist) {
    this.recipelist = recipelist;
  }
  
  public void fillComponents(UIContainer tofill, ViewParameters viewparams, ComponentChecker checker) {
    UIForm form = UIForm.make(tofill, "basic-form");
    for (int i = 0; i < recipelist.size(); ++ i) {
      Recipe recipe = (Recipe) recipelist.get(i);
      String id = recipe.getId().toString();
      UIBranchContainer reciperow = UIBranchContainer.make(form, "recipe-row:", id);
      UIOutput.make(reciperow, "confirm-title", recipe.getTitle());
      UIInternalLink.make(reciperow, "recipe-show", recipe.getTitle(), 
          new EntityCentredViewParameters(RecipeShow.VIEW_ID, 
              new EntityID("Recipe", id), null));
      Category category = recipe.getCategory();
      UIOutput.make(reciperow, "recipe-category", category == null? "" : category.getName());
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
      UIOutput.make(reciperow, "recipe-date", sdf.format(recipe.getDate()));
      UICommand destroy = UICommand.make(reciperow, "recipe-destroy");
      destroy.parameters.add(new UIDeletionBinding("#{Recipe." + id +"}"));
    }
    UIInternalLink.make(tofill, "recipe-create", 
        new EntityCentredViewParameters(RecipeEdit.VIEW_ID, new EntityID("Recipe", "new 1"),
            EntityCentredViewParameters.MODE_NEW));
    UIInternalLink.make(tofill, "index", new SimpleViewParameters(Index.VIEW_ID));    
  }

}
