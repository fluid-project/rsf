/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import uk.org.ponder.beanutil.BeanGetter;
import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.cookbook.Category;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParamsReporter;

public class CategoryShow implements ViewComponentProducer, ViewParamsReporter {
  public static final String VIEW_ID = "category-show";
  private BeanGetter rbg;

  public String getViewID() {
    return VIEW_ID;
  }

  public void setELEvaluator(BeanGetter rbg) {
    this.rbg = rbg;
  }

  public void fillComponents(UIContainer tofill, ViewParameters viewparams,
      ComponentChecker checker) {
    EntityCentredViewParameters ecvp = (EntityCentredViewParameters) viewparams;
    Category category = (Category) ecvp.fetch(rbg);
    UIOutput.make(tofill, "category-name", category.getName());
    UIInternalLink.make(tofill, "category-back", new SimpleViewParameters(
        Categories.VIEW_ID));
  }

  public ViewParameters getViewParameters() {
    return new EntityCentredViewParameters(VIEW_ID, new EntityID("Category",
        null));
  }
}
