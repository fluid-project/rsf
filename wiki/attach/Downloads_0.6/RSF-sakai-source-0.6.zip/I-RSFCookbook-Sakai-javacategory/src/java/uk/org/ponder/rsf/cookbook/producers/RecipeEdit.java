/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.ELReference;
import uk.org.ponder.rsf.components.UICommand;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIELBinding;
import uk.org.ponder.rsf.components.UIForm;
import uk.org.ponder.rsf.components.UIInput;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.components.UIOutputMany;
import uk.org.ponder.rsf.components.UISelect;
import uk.org.ponder.rsf.flow.jsfnav.NavigationCase;
import uk.org.ponder.rsf.flow.jsfnav.NavigationCaseReporter;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParamsReporter;

public class RecipeEdit implements ViewComponentProducer,
    NavigationCaseReporter, ViewParamsReporter {
  public static final String VIEW_ID = "recipe-edit";

  public String getViewID() {
    return VIEW_ID;
  }

  public void fillComponents(UIContainer tofill, ViewParameters viewparams,
      ComponentChecker checker) {
    EntityCentredViewParameters ecvp = (EntityCentredViewParameters) viewparams;
    UIOutput.make(tofill, ecvp.mode
        .equals(EntityCentredViewParameters.MODE_NEW) ? "new-recipe-heading"
        : "edit-recipe-heading");
    UIForm form = UIForm.make(tofill, "basic-form");
    UIInput.make(form, "recipe-title", "#{" + ecvp.getELPath() + ".title}");
    UIInput.make(form, "recipe-description", "#{" + ecvp.getELPath()
        + ".description}");
    UISelect category = UISelect.make(form, "recipe-category");
    category.optionlist = UIOutputMany.make("#{categories-all}",
        "#{fieldGetter.id}");
    category.optionnames = UIOutputMany.make("#{categories-all}",
        "#{fieldGetter.name}");
    category.selection = new UIInput();
    category.selection.valuebinding = new ELReference("#{" + ecvp.getELPath()
        + ".category.id}");
    category.selection.darreshaper = new ELReference("#{id-defunnel}");
    UIInput.make(form, "recipe-instructions", "#{" + ecvp.getELPath()
        + ".instructions}");
    UIInternalLink.make(form, "recipe-show", new EntityCentredViewParameters(
        RecipeShow.VIEW_ID, ecvp.entity));
    form.parameters.add(new UIELBinding("#{" + ecvp.getELPath() + ".date}",
        new Date()));
    UICommand.make(form, "recipe-save");
    UIInternalLink.make(form, "recipe-list", new SimpleViewParameters(
        Recipes.VIEW_ID));
  }

  public List reportNavigationCases() {
    List togo = new ArrayList();
    togo.add(new NavigationCase(null, new SimpleViewParameters(Recipes.VIEW_ID)));
    return togo;
  }

  public ViewParameters getViewParameters() {
    return new EntityCentredViewParameters(VIEW_ID, new EntityID("Recipe", null));
  }

}
