/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.DefaultView;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;

public class Index implements ViewComponentProducer, DefaultView {
  public static final String VIEW_ID = "index";

  public String getViewID() {
    return VIEW_ID;
  }

  public void fillComponents(UIContainer tofill, ViewParameters origviewparams,
      ComponentChecker checker) {
    EntityCentredViewParameters newrecipeparams = new EntityCentredViewParameters();
    newrecipeparams.viewID = RecipeEdit.VIEW_ID;
    newrecipeparams.mode = EntityCentredViewParameters.MODE_NEW;
    newrecipeparams.entity = new EntityID("Recipe", null);
    UIInternalLink.make(tofill, "new-recipe", newrecipeparams);

    UIInternalLink.make(tofill, "recipes-all", new SimpleViewParameters(
        Recipes.VIEW_ID));

    UIInternalLink.make(tofill, "categories-all", new SimpleViewParameters(
        Categories.VIEW_ID));
  }

}
