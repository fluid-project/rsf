/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import java.text.SimpleDateFormat;

import uk.org.ponder.beanutil.BeanGetter;
import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.cookbook.Recipe;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParamsReporter;
/** A request-scope view producer for the "show a single recipe" view */

public class RecipeShow implements ViewComponentProducer, ViewParamsReporter {
  public static final String VIEW_ID = "recipe-show";
  private BeanGetter rbg;
  public String getViewID() {
    return VIEW_ID;
  }

  public void setELEvaluator(BeanGetter rbg) {
    this.rbg = rbg;
  }
  
  public void fillComponents(UIContainer tofill, ViewParameters viewparams, ComponentChecker checker) {
    EntityCentredViewParameters ecvp = (EntityCentredViewParameters) viewparams;
    Recipe recipe = (Recipe) ecvp.fetch(rbg);
    
    UIOutput.make(tofill, "recipe-title", recipe.getTitle());
    UIOutput.make(tofill, "recipe-description", recipe.getDescription());
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    UIOutput.make(tofill, "recipe-date", sdf.format(recipe.getDate()));
    UIOutput.make(tofill, "recipe-instructions", recipe.getInstructions());
    UIInternalLink.make(tofill, "recipe-back", new SimpleViewParameters(Recipes.VIEW_ID));
  }

  public ViewParameters getViewParameters() {
    return new EntityCentredViewParameters(VIEW_ID, new EntityID("Recipe", null));
  }
  
}
