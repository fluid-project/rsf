/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import java.util.ArrayList;
import java.util.List;

import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UICommand;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIForm;
import uk.org.ponder.rsf.components.UIInput;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.flow.jsfnav.NavigationCase;
import uk.org.ponder.rsf.flow.jsfnav.NavigationCaseReporter;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParamsReporter;

public class CategoryEdit implements ViewComponentProducer, NavigationCaseReporter, ViewParamsReporter {
  public static final String VIEW_ID = "category-edit";

  public String getViewID() {
    return VIEW_ID;
  }

  public void fillComponents(UIContainer tofill, ViewParameters viewparams,
      ComponentChecker checker) {
    EntityCentredViewParameters ecvp = (EntityCentredViewParameters) viewparams;
    UIOutput.make(tofill, ecvp.mode
        .equals(EntityCentredViewParameters.MODE_NEW) ? "new-category-heading"
        : "edit-category-heading");
    UIForm form = UIForm.make(tofill, "basic-form");
    UIInput.make(form, "category-name", "#{" + ecvp.getELPath() + ".name}");
    UIInternalLink.make(form, "category-cancel", new SimpleViewParameters(
        Categories.VIEW_ID));
    UICommand.make(form, "category-save");
  }

  public List reportNavigationCases() {
    List togo = new ArrayList();
    //  There is only one submission control on the page, so neglect return value 
    togo.add(new NavigationCase(null, new SimpleViewParameters(Categories.VIEW_ID)));
    return togo;
  }

  public ViewParameters getViewParameters() {
    return new EntityCentredViewParameters(VIEW_ID, new EntityID("Category", null));
  }
}
