/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.cookbook.producers;

import java.util.List;

import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.rsf.components.UIBranchContainer;
import uk.org.ponder.rsf.components.UICommand;
import uk.org.ponder.rsf.components.UIContainer;
import uk.org.ponder.rsf.components.UIDeletionBinding;
import uk.org.ponder.rsf.components.UIForm;
import uk.org.ponder.rsf.components.UIInternalLink;
import uk.org.ponder.rsf.components.UIOutput;
import uk.org.ponder.rsf.cookbook.Category;
import uk.org.ponder.rsf.view.ComponentChecker;
import uk.org.ponder.rsf.view.ViewComponentProducer;
import uk.org.ponder.rsf.viewstate.EntityCentredViewParameters;
import uk.org.ponder.rsf.viewstate.SimpleViewParameters;
import uk.org.ponder.rsf.viewstate.ViewParameters;

public class Categories implements ViewComponentProducer {
  public static final String VIEW_ID = "categories";
  private List categorylist;

  public String getViewID() {
    return VIEW_ID;
  }

  public void setCategoryList(List categorylist) {
    this.categorylist = categorylist;
  }

  public void fillComponents(UIContainer tofill, ViewParameters origviewparams,
      ComponentChecker checker) {
    UIForm form = UIForm.make(tofill, "basic-form");
    for (int i = 0; i < categorylist.size(); ++i) {
      Category category = (Category) categorylist.get(i);
      String id = category.getId().toString();
      UIBranchContainer categoryrow = UIBranchContainer.make(form,
          "category-row:", id);
      
      UIOutput.make(categoryrow, "category-name", category.getName());
      UIInternalLink.make(categoryrow, "category-show",
          new EntityCentredViewParameters(CategoryShow.VIEW_ID, new EntityID(
              "Category", id), null));
      UIInternalLink.make(categoryrow, "category-edit",
          new EntityCentredViewParameters(CategoryEdit.VIEW_ID, new EntityID(
              "Category", id), EntityCentredViewParameters.MODE_EDIT));
      UICommand destroy = UICommand.make(categoryrow, "category-destroy");
      destroy.parameters.add(new UIDeletionBinding("#{Category." + id + "}"));
    }
    UIInternalLink.make(form, "category-create", new EntityCentredViewParameters(
        CategoryEdit.VIEW_ID, new EntityID("Category", "new 1"),
        EntityCentredViewParameters.MODE_NEW));
    UIInternalLink.make(form, "index", new SimpleViewParameters(Index.VIEW_ID));

  }

}
