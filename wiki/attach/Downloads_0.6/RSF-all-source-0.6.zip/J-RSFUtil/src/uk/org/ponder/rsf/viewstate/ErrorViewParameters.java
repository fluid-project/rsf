/*
 * Created on 01-Feb-2006
 */
package uk.org.ponder.rsf.viewstate;

/** A special type of SimpleViewParameters representing an unknown view **/

public class ErrorViewParameters extends SimpleViewParameters {
}
