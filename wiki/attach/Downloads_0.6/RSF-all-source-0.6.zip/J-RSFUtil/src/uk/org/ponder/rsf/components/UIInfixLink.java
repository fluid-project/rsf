/*
 * Created on Sep 22, 2005
 */
package uk.org.ponder.rsf.components;

public class UIInfixLink extends UILink {
  public String pretext;
  public String posttext;
}
