/*
 * Created on 27-Feb-2006
 */
package uk.org.ponder.rsf.view;

public interface ComponentProducerWrapper {
  public ComponentProducer wrapProducer(ComponentProducer towrap);
}
