/*
 * Created on Nov 17, 2005
 */
package uk.org.ponder.rsf.view;

public class ViewNotFoundException extends Exception {
}
