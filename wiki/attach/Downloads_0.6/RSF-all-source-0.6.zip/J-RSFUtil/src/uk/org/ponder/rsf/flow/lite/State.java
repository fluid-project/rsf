/*
 * Created on Nov 21, 2005
 */
package uk.org.ponder.rsf.flow.lite;

public abstract class State {
  public String id;
  
  public abstract void init(); 
}
