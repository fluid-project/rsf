/*
 * Created on Nov 22, 2005
 */
package uk.org.ponder.rsf.flow.lite;

public class ViewState extends ViewableState {
  public TransitionList transitions = new TransitionList();

}
