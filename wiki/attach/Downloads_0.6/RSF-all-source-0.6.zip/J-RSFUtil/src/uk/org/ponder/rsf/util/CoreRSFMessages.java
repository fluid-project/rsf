/*
 * Created on Aug 7, 2005
 */
package uk.org.ponder.rsf.util;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public class CoreRSFMessages {
  public static final String EXPIRED_TOKEN = "error.expiredToken";
}
