/*
 * Created on Jan 16, 2006
 */
package uk.org.ponder.rsf.components;

public class UIInputMany extends UIBoundList {
  public UIInputMany () {
    fossilize = true;
    willinput = true;
  }
}
