/*
 * Created on 04-Feb-2006
 */
package uk.org.ponder.rsac;

class ValueHolder {
  public ValueHolder(String value) {
    this.value = value;
  }

  public String value;
}