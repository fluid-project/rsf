/*
 * Created on 13-Jan-2006
 */
package uk.org.ponder.rsf.hibernate;

import java.io.Serializable;

import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.metadata.ClassMetadata;
import uk.org.ponder.beanutil.BeanResolver;
import uk.org.ponder.conversion.StaticLeafParser;
import uk.org.ponder.util.UniversalRuntimeException;

/** For any Hibernate-persisted bean, return its ID value. The value
 * will be returned as a String, through rendering via the current
 * mappingcontext.  */

public class HibernateIDResolver implements BeanResolver {

  private SessionFactory sessionfactory;
  private StaticLeafParser leafparser;

  public void setSessionFactory(SessionFactory sessionfactory) {
    this.sessionfactory = sessionfactory;
  }
  
  public void setLeafParser(StaticLeafParser leafparser) {
    this.leafparser = leafparser;
  }
  
  public String resolveBean(Object bean) {
    try {
    ClassMetadata cm = sessionfactory.getClassMetadata(bean.getClass());
    Serializable id = cm.getIdentifier(bean).toString();
    return leafparser.render(id);
    }
    catch (Exception e) {
      throw UniversalRuntimeException.accumulate(e, "Error resolving ID for bean " + bean);
    }
  }

}
