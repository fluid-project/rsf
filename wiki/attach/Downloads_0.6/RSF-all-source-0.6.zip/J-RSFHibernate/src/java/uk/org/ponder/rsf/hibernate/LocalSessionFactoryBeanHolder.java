/*
 * Created on Jan 9, 2006
 */
package uk.org.ponder.rsf.hibernate;

import org.springframework.orm.hibernate.LocalSessionFactoryBean;

/** A utility class to obtain the parent Spring factory for the bean. 
 * This is principally used to get the Hibernate Configuration object - 
 * adopt a more portable scheme once the alternatives are clear. 
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 *
 */

public class LocalSessionFactoryBeanHolder {
  private LocalSessionFactoryBean lsfb;
  public void setHolder(LocalSessionFactoryBean lsfb) {
    this.lsfb = lsfb;
  }
  public LocalSessionFactoryBean getHolder() {
    return lsfb;
  }
}
