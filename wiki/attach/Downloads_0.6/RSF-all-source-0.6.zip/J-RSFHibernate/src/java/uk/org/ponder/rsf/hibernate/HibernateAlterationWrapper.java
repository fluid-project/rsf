/*
 * Created on Oct 20, 2005
 */
package uk.org.ponder.rsf.hibernate;

import java.util.ArrayList;
import java.util.List;

import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.Transaction;

import uk.org.ponder.beanutil.entity.EntityIDRewriter;
import uk.org.ponder.rsf.flow.ARIResult;
import uk.org.ponder.rsf.state.entity.NewEntityIDRewriter;
import uk.org.ponder.rsf.viewstate.ViewParameters;
import uk.org.ponder.saxalizer.SAXalizerMappingContext;
import uk.org.ponder.util.RunnableWrapper;
import uk.org.ponder.util.UniversalRuntimeException;

/** An "Alteration Wrapper" appropriate for a straightforward use of Hibernate.
 * This will open and rollback a transaction around every request cycle, 
 * except an action cycle which reports the END_FLOW propagation status (all
 * non-flow cycles will report this). Cooperates with HibernateEntityBeanLocators
 * to ensure new entities are correctly saved, etc. This implementation could
 * be replaced for more advanced usages, for example use of a Hibernate
 * "application" (or "long") transaction strategy.
 * @author Antranig Basman (amb26@ponder.org.uk)
 *
 */

public class HibernateAlterationWrapper implements RunnableWrapper {
  private SessionFactory sessionfactory;
  private Session session;
  private Transaction transaction;
  private List precommits = new ArrayList();
  private ARIResult ariresult;
  private String requesttype;
  private SAXalizerMappingContext mappingcontext;
  private EntityIDRewriter idrewriter;
  private RunnableWrapper chainedwrapper;

  public void setSessionFactory(SessionFactory sessionfactory) {
    this.sessionfactory = sessionfactory;
  }

  public Session getSession() {
    return session;
  }
  
  public Transaction getTransaction() {
    return transaction;
  }
  // precommit actions are currently only registration of ID change listeners,
  // which are actually disused in favour of rewriteNewEntityIDs below.
  public void registerPreCommitAction(Runnable precommit) {
    precommits.add(precommit);
  }
  
  public void setRequestType(String requesttype) {
    this.requesttype = requesttype;
  }
  // NB - this is a lazy dependency (due to circularity from RSFActionHandler) - 
  // use access methods rather than fields.
  public void setARIResult(ARIResult ariresult) {
    this.ariresult = ariresult;
  }
  
  public void setMappingContext(SAXalizerMappingContext mappingcontext) {
    this.mappingcontext = mappingcontext;
  }
  
  public void setEntityIDRewriter(EntityIDRewriter idprocessor) {
    this.idrewriter = idprocessor;
  }
  
  /** Set a wrapper to "wrap-over" the Runnable returned by this wrapper.
   * @param wrapper
   */
  public void setChainedWrapper(RunnableWrapper chainedwrapper) {
    this.chainedwrapper = chainedwrapper;
  }
  
  private boolean willCommit() {
    // Note that ariresult is a lazy bean, and may precipitate all forms of
    // mayhem if it is inappropriately loaded...
    return (requesttype.equals(ViewParameters.ACTION_REQUEST) && 
        ariresult.getPropagateBeans().equals(ARIResult.FLOW_END));
  }
  
  public Runnable wrapRunnable(final Runnable towrap) {
    Runnable togo = new Runnable() {
      public void run() {
        try {
          session = sessionfactory.openSession();
          transaction = session.beginTransaction();
          towrap.run();
       
          if (willCommit()) {
            for (int i = 0; i < precommits.size(); ++ i) {
              ((Runnable)precommits.get(i)).run();
            }
            transaction.commit();
            rewriteNewEntityIDs();
          }
          else {
            transaction.rollback();
          }
        }
        catch (Exception e) {
          HibernateUtil.rollbackTransaction(transaction);
          throw UniversalRuntimeException.accumulate(e);
         
        }
        finally {
          HibernateUtil.closeSession(session);
        }
      }
    };
    return chainedwrapper == null? togo : chainedwrapper.wrapRunnable(togo);
  }

  private void rewriteNewEntityIDs() {
    NewEntityIDRewriter.rewriteEntityIDs(ariresult.getResultingView(), 
        mappingcontext, idrewriter);
  }

}
