/*
 * Created on 10-Jan-2006
 */
package uk.org.ponder.rsf.hibernate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.hibernate.HibernateException;
import uk.org.ponder.beanutil.BeanUtil;
import uk.org.ponder.beanutil.FallbackBeanLocator;
import uk.org.ponder.beanutil.entity.EntityID;
import uk.org.ponder.beanutil.entity.EntityIDRewriter;
import uk.org.ponder.beanutil.entity.NewEntityEntry;
import uk.org.ponder.beanutil.entity.NewEntityReceiver;
import uk.org.ponder.rsf.state.entity.EntityIDAssignmentListener;
import uk.org.ponder.util.UniversalRuntimeException;

/**
 * The central request-scope manager for Hibernate-mapped entities. Maintains a
 * pool of HibernateEntityBeanLocators, one for each entity class, and grafts
 * their paths directly onto its parent in the request-scope container, by
 * virtue of being recognised as a FallbackBeanLocator.
 * 
 * @author Antranig Basman (amb26@ponder.org.uk)
 */

public class HibernateEntityBeanManager implements FallbackBeanLocator,
    EntityIDRewriter, NewEntityReceiver {
  private Map locators = new HashMap();

  private List newentitylisteners = new ArrayList(1);
  // A list of NewEntityEntries, for each new entity created this request.
  private List newentities = new ArrayList();
  private StaticHibernateEBM shebm;
  private HibernateAlterationWrapper haw;

  public void setHibernateAlterationWrapper(HibernateAlterationWrapper haw) {
    this.haw = haw;
  }

  public void setStaticHibernateEBM(StaticHibernateEBM shebm) {
    this.shebm = shebm;
  }

  public void init() {
    shebm.populateRequestMap(locators);
    for (Iterator heblit = locators.values().iterator(); heblit.hasNext();) {
      HibernateEntityBeanLocator hebl = (HibernateEntityBeanLocator) heblit
          .next();
      hebl.setHibernateAlterationWrapper(haw);
      hebl.setNewEntityReceiver(this);
    }
    haw.registerPreCommitAction(new NewEntitySaver());
  }

  // no need for a remove method - remember all these beans are disposable!
  public void addEntityIDListener(EntityIDAssignmentListener eialistener) {
    newentitylisteners.add(eialistener);
  }

  public void receiveNewEntity(NewEntityEntry entry) {
    newentities.add(entry);
  }

  private class NewEntitySaver implements Runnable {
    public void run() {
      try {
        for (int i = 0; i < newentities.size(); ++i) {
          NewEntityEntry entry = (NewEntityEntry) newentities.get(i);
          haw.getSession().save(entry.newent);
          Serializable newid = ((HibernateEntityBeanLocator) entry.holder)
              .getID(entry.newent);
          for (int j = 0; j < newentitylisteners.size(); ++j) {
            EntityIDAssignmentListener eial = (EntityIDAssignmentListener) newentitylisteners
                .get(j);
            eial.IDAssigned(entry.newent, entry.tempid, newid);
          }
        }
      }
      catch (HibernateException he) {
        throw UniversalRuntimeException.accumulate(he,
            "Error saving new entities");
      }
    }
  }

  // For the BeanLocator interface.
  public Object locateBean(String path) {
    return locators.get(path);
  }

  // For the EntityIDRewriter interface.
  public void postCommit(EntityID toadjust) {
    String entityname = toadjust.entityname;
    HibernateEntityBeanLocator hebl = (HibernateEntityBeanLocator) locators
        .get(entityname);
    if (toadjust.ID.startsWith(BeanUtil.NEW_ENTITY_PREFIX)) {
      Object committed = hebl.getDeliveredBeans().get(toadjust.ID);
      if (committed == null) {
        throw UniversalRuntimeException.accumulate(new IllegalArgumentException(), 
            "Entity of type " + toadjust.entityname + " with ID " + toadjust.ID
            + " was not created on this cycle");
      }
      toadjust.ID = hebl.getIDString(committed);
    }
  }

}
