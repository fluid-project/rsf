/*
 * Created on Feb 18, 2005
 */
package uk.org.ponder.errorutil;

/**
 * @author Antranig Basman (antranig@caret.cam.ac.uk)
 * 
 */
public class ConfigurationException extends Throwable {

}
